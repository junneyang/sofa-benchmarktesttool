#include <stdio.h>

#include "Configure.h"
#include "com_log.h"
#include "comlogplugin.h"
#include "google/protobuf/stubs/common.h"
#include "hulu/pbrpc/rpc_channel.h"
#include "hulu/pbrpc/sync_point.h"
#include "hulu/pbrpc/common.h"
#include "hulu/pbrpc/rpc_client_controller.h"

#include "pbrpc.pb.h"
#include "pbrpc_service.pb.h"

using namespace baidu::hulu::pbrpc;
using namespace lbs::da::openservice;

bool s_callbacked = false;

void UpCallBack(GetItemsByItemRequest* request, 
    GetItemsByItemResponse* response,
    baidu::hulu::pbrpc::RpcClientContext* controller)
{
    if(controller->Failed()) 
    {
	std::cout<<"failed"<<std::endl;	
    } 
    else 
    {
	std::cout<<"success"<<std::endl;
	int size = response->items_size();
	printf("result size:%d\n",size );
	for (int idx = 0; idx < size; idx ++)
	{
	    Item item = response->items(idx);
	    std::string id = item.id();
	    printf("idx:%d, item id:%s\n", idx, id.c_str());
	}
    }
    delete request;
    delete response;
    delete controller;
    s_callbacked = true;
}

int main()
{
    comcfg::Configure conf;
    assert(conf.load("./", "rpc_client.conf") == 0);
    comlog_init(conf["Log"]);

    RpcClientOptions options;
    options.keepalive_timeout_second = 5000000;
    RpcClient rpc_client;
    rpc_client.set_options(options);
    rpc_client.Start();

    RpcChannel rpc_channel("10.81.24.122:7790", &rpc_client);

    GetItemsByItemRequest* request = new GetItemsByItemRequest();
    RequestHeader* header = request->mutable_header();
    header->set_servicekey("key1");
    header->set_secretkey("pass");
    header->set_subservice("sub");
    request->set_algorithmid("a2c");
    request->add_item_ids("17580413039071382724");
    
    GetItemsByItemResponse* response = new GetItemsByItemResponse();
    RpcClientContext* cntl = new RpcClientContext();
    ItemService_Stub stub(&rpc_channel);

    pb::Closure* done = pb::NewCallback(&UpCallBack, request, response, cntl);

    stub.GetItemsByItem(cntl, request, response, done);
	
    while (!s_callbacked) 
    {
        usleep(100000);
    }
    return 0;
}

