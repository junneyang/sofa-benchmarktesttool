#include <stdio.h>

#include "Configure.h"
#include "com_log.h"
#include "comlogplugin.h"
#include "google/protobuf/stubs/common.h"
#include "hulu/pbrpc/rpc_channel.h"
#include "hulu/pbrpc/sync_point.h"
#include "hulu/pbrpc/common.h"
#include "hulu/pbrpc/rpc_client_controller.h"

#include "pbrpc.pb.h"
#include "pbrpc_service.pb.h"

using namespace baidu::hulu::pbrpc;
using namespace lbs::da::openservice;

bool s_callbacked = false;

void UpCallBack(NuomiUserPreferenceRequest* request, 
	NuomiUserPreferenceResponse* response,
	baidu::hulu::pbrpc::RpcClientContext* controller)
{
	if(controller->Failed())
	{
		std::cout << "failed" << std::endl;
	}
	else
	{
		std::cout << "success" << std::endl;
		int result_type = response->result_type();
		int size = response->features_size();
		std::cout << "result_type: " << result_type << std::endl;
		std::cout << "feature size: " << size << std::endl;
		for (int i = 0; i < size; ++i)
		{
			FeatureInfo feature = response->features(i);
			std::string type = feature.feature_name();
			int score_size = feature.score_infos_size();
			std::cout << i << ":" << type << ", size=" << score_size << std::endl;
			for (int j = 0; j < score_size; ++j)
			{
				ScoreInfo score_info = feature.score_infos(j);
				std::string id = score_info.featureid();
				double score = score_info.score();
				std::cout << "\t" << j << ":" << id << "\t" << score << std::endl;
			}
		}
	}
	delete request;
	delete response;
	delete controller;
	s_callbacked = true;
}

int main()
{
	comcfg::Configure conf;
	assert(conf.load("./", "rpc_client.conf") == 0);
	comlog_init(conf["Log"]);

	RpcClientOptions options;
	options.keepalive_timeout_second = 5000000;
	RpcClient rpc_client;
	rpc_client.set_options(options);
	rpc_client.Start();

	RpcChannel rpc_channel("10.48.55.39:7790", &rpc_client);

	NuomiUserPreferenceRequest* request = new NuomiUserPreferenceRequest();
	RequestHeader* header = request->mutable_header();
	header->set_servicekey("key1");
	header->set_secretkey("pass");
	header->set_subservice("sub");
	request->set_id("8432843hjjjf|3383432932");
	request->set_id_type(CUID);
	std::cout << "PASSPORT_ID: " << PASSPORT_ID << std::endl;
	std::cout << "BAIDU_ID: " << BAIDU_ID << std::endl;
	std::cout << "CUID: " << CUID << std::endl;
	NuomiUserPreferenceResponse* response = new NuomiUserPreferenceResponse();
	RpcClientContext* cntl = new RpcClientContext();
	UserService_Stub stub(&rpc_channel);

	pb::Closure* done = pb::NewCallback(&UpCallBack, request, response, cntl);

	stub.GetNuomiUserPreference(cntl, request, response, done);
	
	while (!s_callbacked)
	{
		usleep(100000);
	}
	return 0;
}

