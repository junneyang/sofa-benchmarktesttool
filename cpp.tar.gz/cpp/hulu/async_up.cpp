#include <stdio.h>

#include "Configure.h"
#include "com_log.h"
#include "comlogplugin.h"
#include "google/protobuf/stubs/common.h"
#include "hulu/pbrpc/rpc_channel.h"
#include "hulu/pbrpc/sync_point.h"
#include "hulu/pbrpc/common.h"
#include "hulu/pbrpc/rpc_client_controller.h"

#include "pbrpc.pb.h"
#include "pbrpc_service.pb.h"

using namespace baidu::hulu::pbrpc;
using namespace lbs::da::openservice;

bool s_callbacked = false;

void UpCallBack(GetUserPreferenceRequest* request, 
    GetUserPreferenceResponse* response,
    baidu::hulu::pbrpc::RpcClientContext* controller)
{
    if(controller->Failed()) 
    {
	std::cout<<"failed"<<std::endl;	
    } 
    else 
    {
	std::cout<<"success"<<std::endl;
	int size = response->values_size();
	printf("result size:%d\n",size );
	for (int idx = 0; idx < size; idx ++)
	{
	    UserPreference up = response->values(idx);
	    std::string tag = up.tag();
	    printf("idx:%d, tag:%s\n", idx, tag.c_str());
	}
    }
    delete request;
    delete response;
    delete controller;
    s_callbacked = true;
}

int main()
{
    comcfg::Configure conf;
    assert(conf.load("./", "rpc_client.conf") == 0);
    comlog_init(conf["Log"]);

    RpcClientOptions options;
    options.keepalive_timeout_second = 5000000;
    RpcClient rpc_client;
    rpc_client.set_options(options);
    rpc_client.Start();

    RpcChannel rpc_channel("10.81.24.122:7790", &rpc_client);

    GetUserPreferenceRequest* request = new GetUserPreferenceRequest();
    RequestHeader* header = request->mutable_header();
    header->set_servicekey("key1");
    header->set_secretkey("pass");
    header->set_subservice("sub");
    request->set_cuid("00016c5afe5b6c4ab68de8ed86354896");
    request->add_srctype("tcu");
    
    GetUserPreferenceResponse* response = new GetUserPreferenceResponse();
    RpcClientContext* cntl = new RpcClientContext();
    UserService_Stub stub(&rpc_channel);

    pb::Closure* done = pb::NewCallback(&UpCallBack, request, response, cntl);

    stub.GetUserPreference(cntl, request, response, done);
	
    while (!s_callbacked) 
    {
        usleep(100000);
    }
    return 0;
}

