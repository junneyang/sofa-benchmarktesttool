/*
 * test_client.cpp
 *
 *  Created on: 2013��10��24��
 *      Author: wangqiying
 */


#include <string.h>
#include <stdio.h>
#include <time.h>
#include <bsl/var/IVar.h>
#include <bsl/ResourcePool.h>
#include <bsl/var/implement.h>
#include <sys/uio.h>

#include <ub_log.h>
#include <ubclient_include.h>
#include "ubclient_manager2.h"

#include <vector>
#include <comlogplugin.h>
#include "BlockingClient.h"
#include "NonblockingClient.h"
#include "AsyncClient.h"
#include "UbTransport.h"
#include "PbProtocol.h"
#include "pbrpc.pb.h"
#include "pbrpc_service.pb.h"
#include "google/protobuf/message.h"
#include "google/protobuf/descriptor.h"
#include "google/protobuf/service.h"
#include <Configure.h>
#include "util/pbrpc_log.h"
#include <pthread.h>

ub::UbClientManager2* ubmgr1;

using namespace std;
using namespace pbrpc;
using namespace lbs::da::openservice;
namespace pb = google::protobuf;

static bool finished = false;
void UppsCallback(RpcClientController* controller, GetRegularStayPointRequest* request,
	       	GetRegularStayPointResponse* response,	UserService_Stub* stub)
{
    fprintf(stderr, "#########################Recv response value size %d\n", response->value().size());
    controller->setFinished(true);
    printf("Result list:------------------------------------------------\n");
    for(int i = 0; i < response->value().size(); i++)
    {
	    printf("\n%d result:\n", i);
	    RegularStayPoint st = response->value(i);
	    double x = st.longitude();
	    double y = st.latitude();
	    printf("x:%f, y:%f\n", x, y);
    }
    printf("result list end----------------------------------------------\n");


    delete controller;
    delete response;
    delete request;
    delete stub;
    fprintf(stderr, "async call in callback\n");
    finished = true;
}

void* upps_asynccall(const char* key)
{
    UbTransport* transport = new UbTransport(ubmgr1);
    PbProtocol* protocol = new PbProtocol(transport);
    try 
    {
        AsyncClient* client = new AsyncClient(protocol);
        UserService_Stub* stub = new UserService_Stub(client, ::google::protobuf::Service::STUB_OWNS_CHANNEL);
	RpcClientController* controller = new RpcClientController();

	controller->set_log_id(33333);
	controller->setChannel("service1");
        controller->setService("UserService");
	GetRegularStayPointRequest* request = new GetRegularStayPointRequest();
	request->mutable_header()->set_secretkey("pass");
	request->mutable_header()->set_subservice("sub");
	request->mutable_header()->set_servicekey("key1");
	GetRegularStayPointResponse* response = new GetRegularStayPointResponse();
	google::protobuf::Closure* done = NewCallback(&UppsCallback,controller, request, response, stub);
	if(NULL != key)
	{
		request->set_cuid(key);
	}else
	{
		request->set_cuid("key1");
	}

	stub->GetUserRegularStayPoint(controller,request,response, done);
    }
    catch(bsl::Exception &e)
    {
        std::cout<<e.what()<<std::endl;
    }
    while(!finished)
    {
 	sleep(1);
    }

    delete transport;
    delete protocol;
    return NULL;
}

int main(int argc, char ** argv)
{
    ubmgr1 = new ub::UbClientManager2;

    comcfg::Configure conf;
    assert (conf.load("./conf", "upps_client.conf") == 0);
    comlog_init(conf["Log"]);
    int ret = ubmgr1->load(conf["UbClientConfig"]);
    if (ret == 0)
    {
 	fprintf(stderr, "%s\n", "init ok");
    }
    else
    {
	fprintf(stderr, "%s\n", "init error");
	return -1;
    }

    const char* key = NULL;
    if(argc == 2)
    {
 	key = argv[1];
    }
    upps_asynccall(key);

    delete ubmgr1;
	return 0;
}






