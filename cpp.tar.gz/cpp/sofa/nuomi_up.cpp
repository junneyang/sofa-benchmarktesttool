#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <cstring>
#include <vector>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include <algorithm>
#include <pthread.h>
#include <unistd.h>

#include "google/protobuf/text_format.h"

#include "google/protobuf/stubs/common.h"
#include "sofa/pbrpc/rpc_channel.h"
#include "sofa/pbrpc/common.h"
#include "sofa/pbrpc/rpc_controller.h"

#include <sofa/pbrpc/pbrpc.h>
#include "pbrpc.pb.h"
#include "pbrpc_service.pb.h"

//#include "bn_rp_poi_association.h"

using namespace std;

using namespace lbs::da::openservice;

bool s_callbacked = false;

void UpCallBack(NuomiUserPreferenceRequest* request, 
	NuomiUserPreferenceResponse* response,
	sofa::pbrpc::RpcController* controller)
{
	if(controller->Failed())
	{
		std::cout << "failed" << std::endl;
	}
	else
	{
		//std::cout << "success" << std::endl;
		//int result_type = response->result_type();
		int size = response->features_size();
		//std::cout << "result_type: " << result_type << std::endl;
		//std::cout << "feature size: " << size << std::endl;
		
		for (int i = 0; i < size; ++i)
		{
			FeatureInfo feature = response->features(i);
			std::string type = feature.feature_name();
			ScoreInfo score_info=feature.score_info();
			std::cout << type << " "<< score_info.featureid() <<":"<<score_info.score()<<" ";
		}
	}
	delete request;
	delete response;
	delete controller;
	s_callbacked = true;
}

int main(int argc, char** argv)
{
	/*comcfg::Configure conf;
	assert(conf.load("./", "rpc_client.conf") == 0);
	comlog_init(conf["Log"]);*/
	string ip_port;
	string id;
	int id_type;
	
	if(argc == 4){
		ip_port=argv[1];
		id=argv[2];
		id_type=atoi(argv[3]);
	}else{
		cout<<"Usage:"<<endl;
		cout<<"./nuomi_up IP:PORT CUID/BAIDUID ID_TYPE"<<endl;
		cout<<"Example:"<<endl;
		cout<<"./nuomi_up 10.48.55.39:7789 3uiuiueiukjfdkj:FG=3 2"<<endl;
		return -1;
	}
	
	sofa::pbrpc::RpcClientOptions client_options;
	sofa::pbrpc::RpcClient rpc_client(client_options);
	// Define an rpc channel.
	sofa::pbrpc::RpcChannelOptions channel_options;
	//sofa::pbrpc::RpcChannel rpc_channel(&rpc_client, "10.48.55.39:7789", channel_options);
	sofa::pbrpc::RpcChannel rpc_channel(&rpc_client, ip_port, channel_options);
	
	NuomiUserPreferenceRequest* request = new NuomiUserPreferenceRequest();
	RequestHeader* header = request->mutable_header();
	header->set_servicekey("key1");
	header->set_secretkey("pass");
	header->set_subservice("sub");
	request->set_id(id);
	if(id_type ==1){
		request->set_id_type(PASSPORT_ID);
	}else if(id_type ==2){
		request->set_id_type(BAIDU_ID);
	}else if(id_type ==3){
		request->set_id_type(CUID);
	}
	/*std::cout << "PASSPORT_ID: " << PASSPORT_ID << std::endl;
	std::cout << "BAIDU_ID: " << BAIDU_ID << std::endl;
	std::cout << "CUID: " << CUID << std::endl;*/
	NuomiUserPreferenceResponse* response = new NuomiUserPreferenceResponse();
	// Prepare parameters.
	sofa::pbrpc::RpcController* cntl = new sofa::pbrpc::RpcController();
	cntl->SetTimeout(3000);
	
	UserService_Stub stub(&rpc_channel);

	google::protobuf::Closure* done = sofa::pbrpc::NewClosure(&UpCallBack, request, response, cntl);

	stub.GetNuomiUserPreference(cntl, request, response, done);
	
	while (!s_callbacked)
	{
		usleep(100000);
	}
	return 0;
}



