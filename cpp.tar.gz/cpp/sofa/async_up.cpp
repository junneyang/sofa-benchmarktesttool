/***************************************************************************
 * 
 * Copyright (c) 2014 Baidu.com, Inc. All Rights Reserved
 * 
 **************************************************************************/

#include "google/protobuf/stubs/common.h"
#include "sofa/pbrpc/rpc_channel.h"
#include "sofa/pbrpc/common.h"
#include "sofa/pbrpc/rpc_controller.h"

#include <sofa/pbrpc/pbrpc.h>
#include "pbrpc.pb.h"
#include "pbrpc_service.pb.h"

using namespace lbs::da::openservice;

void CallbackFunc(sofa::pbrpc::RpcController* cntl,
        lbs::da::openservice::GetUserPreferenceRequest* request,
        lbs::da::openservice::GetUserPreferenceResponse* response,
        bool* callbacked)
{
    SLOG(NOTICE, "RemoteAddress=%s", cntl->RemoteAddress().c_str());
    SLOG(NOTICE, "IsRequestSent=%s", cntl->IsRequestSent() ? "true" : "false");
    if (cntl->IsRequestSent())
    {
        SLOG(NOTICE, "LocalAddress=%s", cntl->LocalAddress().c_str());
        SLOG(NOTICE, "SentBytes=%ld", cntl->SentBytes());
    }

    if (cntl->Failed())
    {
        SLOG(ERROR, "request failed: %s", cntl->ErrorText().c_str());
    }
    else 
    {
        SLOG(NOTICE, "request SUCCESS! ");
        int size = response->values_size();
        printf("result size:%d\n",size );
        for (int idx = 0; idx < size; idx ++)
        {
            UserPreference up = response->values(idx);
            std::string tag = up.tag();
            int32_t level = up.level();
            float value = up.value();
            std::string srcType = "";
            if (up.has_srctype())
            {
                srcType = up.srctype();
            }
            printf("idx:%d, tag:%s, level:%d, value:%f, srctype:%s\n", 
                    idx, tag.c_str(), level, value, srcType.c_str());
        }
    }
    delete cntl;
    delete request;
    delete response;
    *callbacked = true;
}

int main()
{
    //SOFA_PBRPC_SET_LOG_LEVEL(NOTICE);

    // Define an rpc server.
    sofa::pbrpc::RpcClientOptions client_options;
    sofa::pbrpc::RpcClient rpc_client(client_options);

    // Define an rpc channel.
    sofa::pbrpc::RpcChannelOptions channel_options;
    sofa::pbrpc::RpcChannel rpc_channel(&rpc_client, "nj02-lbs-profile01.nj02:7789",
            channel_options);

    // Prepare parameters.
    sofa::pbrpc::RpcController* cntl = new sofa::pbrpc::RpcController();
    cntl->SetTimeout(3000);
    GetUserPreferenceRequest* request = new GetUserPreferenceRequest();
    RequestHeader* header = request->mutable_header();
    header->set_servicekey("key1");
    header->set_secretkey("pass");
    header->set_subservice("sub");
    request->set_cuid("000001AD1E678177827E1AD53C52919F|875561720000168");
    request->add_srctype("amc");

    
    GetUserPreferenceResponse* response = new GetUserPreferenceResponse();
    bool callbacked = false;

    google::protobuf::Closure* done = sofa::pbrpc::NewClosure(
              &CallbackFunc, cntl, request, response, &callbacked);
    
    // Async call.
    UserService_Stub stub(&rpc_channel);
    stub.GetUserPreference(cntl, request, response, done);
    
    // Wait call done.
    while (!callbacked)
    {
        usleep(100000);
    }
    return EXIT_SUCCESS;
}





















/* vim: set expandtab ts=4 sw=4 sts=4 tw=100: */
